from setuptools import setup

setup(
    name='library',
    packages=['library'],
    include_package_data=True,
    install_requires=[
        'flask',
    ],
)